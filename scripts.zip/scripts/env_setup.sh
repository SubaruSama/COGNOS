# Instalattion stuff
echo 'Installing the necessary files for spacy...'
pip install -U pip setuptools whell
pip install -U 'spacy[transformers,lookups]'
python3 -m spacy download en_core_web_md
python3 -m spacy download en_core_web_trf

# Filling the config file for spacy training
echo 'Moving to the dir /spacy/config-files...'
cd /spacy/config-files

echo 'Filling the config.cfg file based on base_config.cfg...'
python3 -m spacy init fill-config

echo 'Done'