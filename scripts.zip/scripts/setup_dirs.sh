echo 'Creating the dir /spacy/datasets...'
mkdir /spacy/datasets/
echo 'Done'

echo 'Creating the dir /spacy/models for the trained models...'
mkdir /spacy/models
echo 'Done'